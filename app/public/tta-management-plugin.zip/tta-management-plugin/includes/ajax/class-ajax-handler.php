<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class TTA_Ajax_Handler {

    /**
     * Singleton instance
     *
     * @return TTA_Ajax_Handler
     */
    public static function get_instance() {
        static $inst;
        return $inst ?: $inst = new self();
    }

    /**
     * Constructor: hook our AJAX actions
     */
    private function __construct() {
        // generic placeholder AJAX
        add_action( 'wp_ajax_tta_action',        [ $this, 'handle_ajax' ] );
        add_action( 'wp_ajax_nopriv_tta_action', [ $this, 'handle_ajax' ] );

        // Create‐only event save
        add_action( 'wp_ajax_tta_save_event',     [ $this, 'save_event' ] );

        // Update existing event
        add_action( 'wp_ajax_tta_update_event',   [ $this, 'update_event' ] );

        // Fetch raw event data (for inline JSON)
        add_action( 'wp_ajax_tta_get_event',      [ $this, 'get_event' ] );

        // Fetch full create/edit form HTML
        add_action( 'wp_ajax_tta_get_event_form', [ $this, 'get_event_form' ] );
    }

    /**
     * Placeholder for existing AJAX
     */
    public function handle_ajax() {
        wp_send_json_success();
    }

    /**
     * Handle AJAX request to create a new Event (insert only),
     * plus associated ticket & waitlist records, and auto-create a Page.
     */
    public function save_event() {
        // 0) Verify nonce
        check_ajax_referer( 'tta_event_save_action', 'tta_event_save_nonce' );

        global $wpdb;
        $events_table   = $wpdb->prefix . 'tta_events';
        $tickets_table  = $wpdb->prefix . 'tta_tickets';
        $waitlist_table = $wpdb->prefix . 'tta_waitlist';

        // 1) Gather & sanitize the incoming event data
        $ute_id             = uniqid( 'tte_', true );
        $address            = implode(
            ' - ',
            array_filter( [
                sanitize_text_field( $_POST['street_address'] ?? '' ),
                sanitize_text_field( $_POST['address_2']      ?? '' ),
                sanitize_text_field( $_POST['city']           ?? '' ),
                sanitize_text_field( $_POST['state']          ?? '' ),
                sanitize_text_field( $_POST['zip']            ?? '' ),
            ] )
        );
        $start              = sanitize_text_field( $_POST['start_time'] ?? '' );
        $end                = sanitize_text_field( $_POST['end_time']   ?? '' );
        $time               = $start . '|' . $end;
        $waitlist_available = sanitize_text_field( $_POST['waitlistavailable'] ?? '0' );
        $attendance_limit   = intval( $_POST['attendancelimit'] ?? 0 );

        $event_data = [
            'ute_id'               => $ute_id,
            'name'                 => sanitize_text_field( $_POST['name']                 ?? '' ),
            'date'                 => sanitize_text_field( $_POST['date']                 ?? '' ),
            'all_day_event'        => sanitize_text_field( $_POST['all_day_event']        ?? '0' ),
            'time'                 => $time,
            'virtual_event'        => sanitize_text_field( $_POST['virtual_event']        ?? '0' ),
            'address'              => $address,
            'venueurl'             => esc_url_raw   ( $_POST['venueurl']            ?? '' ),
            'type'                 => sanitize_text_field( $_POST['type']                 ?? '' ),
            'baseeventcost'        => floatval        ( $_POST['baseeventcost']        ?? 0 ),
            'discountedmembercost' => floatval        ( $_POST['discountedmembercost'] ?? 0 ),
            'attendancelimit'      => $attendance_limit,
            'waitlistavailable'    => $waitlist_available,
            'refundsavailable'     => sanitize_text_field( $_POST['refundsavailable']    ?? '0' ),
            'discountcode'         => sanitize_text_field( $_POST['discountcode']        ?? '' ),
            'url2'                 => esc_url_raw   ( $_POST['url2']                ?? '' ),
            'url3'                 => esc_url_raw   ( $_POST['url3']                ?? '' ),
            'url4'                 => esc_url_raw   ( $_POST['url4']                ?? '' ),
            'mainimageid'          => intval          ( $_POST['mainimageid']         ?? 0 ),
            'otherimageids'        => sanitize_text_field( $_POST['otherimageids']       ?? '' ),
        ];

        // 2) Insert the event record
        $wpdb->insert( $events_table, $event_data );
        $event_id = $wpdb->insert_id;
        if ( ! $event_id ) {
            wp_send_json_error( [ 'message' => 'Failed to create event.' ] );
        }

        // 3) Always create a ticket record (with a placeholder waitlist_id)
        $ticket_data = [
            'event_ute_id'         => $ute_id,
            'event_name'           => $event_data['name'],
            'waitlist_id'          => 0,
            'baseeventcost'        => $event_data['baseeventcost'],
            'discountedmembercost' => $event_data['discountedmembercost'],
            'attendancelimit'      => $attendance_limit,
        ];
        $wpdb->insert( $tickets_table, $ticket_data );
        $ticket_id = $wpdb->insert_id;
        if ( ! $ticket_id ) {
            wp_send_json_error( [ 'message' => 'Failed to create ticket.' ] );
        }

        // 4) If waitlists are enabled, create one now
        $waitlist_id = 0;
        if ( '1' === $waitlist_available ) {
            $waitlist_data = [
                'event_ute_id' => $ute_id,
                'ticket_id'    => $ticket_id,
                'event_name'   => $event_data['name'],
                'userids'      => '',  // start empty
            ];
            $wpdb->insert( $waitlist_table, $waitlist_data );
            $waitlist_id = $wpdb->insert_id;
            if ( ! $waitlist_id ) {
                wp_send_json_error( [ 'message' => 'Failed to create waitlist.' ] );
            }
            // 5) Now update the ticket record with its waitlist_id
            $wpdb->update(
                $tickets_table,
                [ 'waitlist_id' => $waitlist_id ],
                [ 'id'           => $ticket_id ]
            );
        }

        // 6) Finally update the event with its ticket & waitlist IDs
        $wpdb->update(
            $events_table,
            [
                'ticket_id'   => $ticket_id,
                'waitlist_id' => $waitlist_id,
                // --- New: will update 'page_id' right after creating the page below ---
            ],
            [ 'id' => $event_id ]
        );

        // 7) Auto-create a dedicated WordPress Page for this Event
        $page_data = [
            'post_title'   => $event_data['name'],
            'post_content' => '',          // you can prefill with a template or leave blank
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'meta_input'   => [
                '_tta_event_id' => $event_id // store back-reference for your page manager
            ],
        ];
        $page_id = wp_insert_post( $page_data );

        if ( $page_id && ! is_wp_error( $page_id ) ) {
            // 1) assign our custom template
            update_post_meta( $page_id, '_wp_page_template', 'event-page-template.php' );

            // 2) store the page_id back on the event record
            $wpdb->update(
                $wpdb->prefix . 'tta_events',
                [ 'page_id' => $page_id ],
                [ 'id'      => $event_id ]
            );
        }

        // 8) Save the TinyMCE “description” into the post_content of the new page:
        if ( isset( $_POST['description'] ) ) {
            // sanitize the HTML allowed by TinyMCE
            $content = wp_kses_post( $_POST['description'] );
            wp_update_post( [
                'ID'           => $page_id,
                'post_content' => $content,
            ] );
        }
        // end page creation/update block

        // 9) Return success
        wp_send_json_success( [
            'message'  => 'Event, ticket, waitlist (if any), and page created successfully.',
            'id'       => $event_id,
            'ticket'   => $ticket_id,
            'waitlist' => $waitlist_id,
            'page_id'  => $page_id ?? 0,
        ] );
    }





    /**
     * Update an existing event, plus its ticket & waitlist records.
     */
    public function update_event() {
        check_ajax_referer( 'tta_event_save_action', 'tta_event_save_nonce' );

        if ( empty( $_POST['tta_event_id'] ) ) {
            wp_send_json_error([ 'message' => 'Missing event ID.' ]);
        }

        global $wpdb;
        $events_table   = $wpdb->prefix . 'tta_events';
        $tickets_table  = $wpdb->prefix . 'tta_tickets';
        $waitlist_table = $wpdb->prefix . 'tta_waitlist';

        $id = intval( $_POST['tta_event_id'] );

        // 1) Combine address & time
        $address = implode(
            ' - ',
            array_filter([
                sanitize_text_field( $_POST['street_address'] ?? '' ),
                sanitize_text_field( $_POST['address_2']     ?? '' ),
                sanitize_text_field( $_POST['city']          ?? '' ),
                sanitize_text_field( $_POST['state']         ?? '' ),
                sanitize_text_field( $_POST['zip']           ?? '' ),
            ])
        );
        $start = sanitize_text_field( $_POST['start_time'] ?? '' );
        $end   = sanitize_text_field( $_POST['end_time']   ?? '' );
        $time  = $start . '|' . $end;

        // 2) Build event data
        $event_data = [
            'name'                 => sanitize_text_field( $_POST['name']                 ?? '' ),
            'date'                 => sanitize_text_field( $_POST['date']                 ?? '' ),
            'all_day_event'        => sanitize_text_field( $_POST['all_day_event']        ?? '0' ),
            'time'                 => $time,
            'virtual_event'        => sanitize_text_field( $_POST['virtual_event']        ?? '0' ),
            'address'              => $address,
            'venueurl'             => esc_url_raw   ( $_POST['venueurl']            ?? '' ),
            'type'                 => sanitize_text_field( $_POST['type']                 ?? '' ),
            'baseeventcost'        => floatval        ( $_POST['baseeventcost']        ?? 0 ),
            'discountedmembercost' => floatval        ( $_POST['discountedmembercost'] ?? 0 ),
            'attendancelimit'      => intval          ( $_POST['attendancelimit']      ?? 0 ),
            'waitlistavailable'    => sanitize_text_field( $_POST['waitlistavailable']   ?? '0' ),
            'refundsavailable'     => sanitize_text_field( $_POST['refundsavailable']    ?? '0' ),
            'discountcode'         => sanitize_text_field( $_POST['discountcode']        ?? '' ),
            'url2'                 => esc_url_raw   ( $_POST['url2']                ?? '' ),
            'url3'                 => esc_url_raw   ( $_POST['url3']                ?? '' ),
            'url4'                 => esc_url_raw   ( $_POST['url4']                ?? '' ),
            'mainimageid'          => intval          ( $_POST['mainimageid']         ?? 0 ),
            'otherimageids'        => sanitize_text_field( $_POST['otherimageids']       ?? '' ),
        ];

        // 3) Update the event row
        $updated = $wpdb->update( $events_table, $event_data, [ 'id' => $id ] );
        if ( false === $updated ) {
            wp_send_json_error([ 'message' => 'Failed to update event.' ]);
        }

        // 4) Fetch fresh event to get ute_id, ticket_id & waitlist_id
        $event        = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$events_table} WHERE id = %d", $id ), ARRAY_A );
        $ute_id       = $event['ute_id'];
        $ticket_id    = intval( $event['ticket_id'] );
        $waitlist_id  = intval( $event['waitlist_id'] );

        // 5) Update its ticket record
        $ticket_update = [
            'event_name'           => $event_data['name'],
            'baseeventcost'        => $event_data['baseeventcost'],
            'discountedmembercost' => $event_data['discountedmembercost'],
            'attendancelimit'      => $event_data['attendancelimit'],
        ];
        $wpdb->update(
            $tickets_table,
            $ticket_update,
            [ 'event_ute_id' => $ute_id ]
        );

        // 6) Handle the waitlist
        $waitlist_available = sanitize_text_field( $_POST['waitlistavailable'] ?? '0' );
        $waitlist_csv       = sanitize_text_field( $_POST['waitlist_userids']    ?? '' );

        if ( '1' === $waitlist_available ) {
            if ( $waitlist_id ) {
                // just update name + CSV
                $wpdb->update(
                    $waitlist_table,
                    [
                        'event_name' => $event_data['name'],
                        'userids'    => $waitlist_csv,
                    ],
                    [ 'id' => $waitlist_id ]
                );
            } else {
                // create brand-new waitlist
                $wpdb->insert( $waitlist_table, [
                    'event_ute_id' => $ute_id,
                    'ticket_id'    => $ticket_id,
                    'event_name'   => $event_data['name'],
                    'userids'      => $waitlist_csv,
                ] );
                $new_wl = $wpdb->insert_id;
                if ( $new_wl ) {
                    // record it back on the event
                    $wpdb->update(
                        $events_table,
                        [ 'waitlist_id' => $new_wl ],
                        [ 'id'           => $id     ]
                    );
                }
            }
        }
        // if disabling waitlist (0), we leave the old waitlist row untouched

        wp_send_json_success([
            'message' => 'Event updated successfully.',
            'id'      => $id,
        ]);
    }

     public function get_event() {
        check_ajax_referer( 'tta_event_get_action', 'get_event_nonce' );

        if ( empty( $_POST['event_id'] ) ) {
            wp_send_json_error([ 'message' => 'Missing event ID.' ]);
        }

        global $wpdb;
        $id    = intval( $_POST['event_id'] );
        $table = $wpdb->prefix . 'tta_events';
        $event = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );

        if ( ! $event ) {
            wp_send_json_error([ 'message' => 'Event not found.' ]);
        }
        wp_send_json_success([ 'event' => $event ]);
    }

    public function get_event_form() {
        check_ajax_referer( 'tta_event_get_action', 'get_event_nonce' );

        if ( empty( $_POST['event_id'] ) ) {
            wp_send_json_error([ 'message' => 'Missing event ID.' ]);
        }

        $_GET['event_id'] = intval( $_POST['event_id'] );
        ob_start();
        include plugin_dir_path( __FILE__ ) . '../admin/views/events-edit.php';
        $html = ob_get_clean();

        wp_send_json_success([ 'html' => $html ]);
    }
}

TTA_Ajax_Handler::get_instance();
