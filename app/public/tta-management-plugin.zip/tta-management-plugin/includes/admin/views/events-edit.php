<?php
global $wpdb;
$table   = $wpdb->prefix . 'tta_events';
$editing = false;
$event   = [];

// Load existing for editing
if ( isset( $_GET['event_id'] ) ) {
    $event_id = intval( $_GET['event_id'] );
    $event    = $wpdb->get_row(
        $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $event_id ),
        ARRAY_A
    );
    if ( $event ) {
        $editing = true;
    }
}
?>

<form method="post" id="tta-event-edit-form">
    <?php wp_nonce_field( 'tta_event_save_action', 'tta_event_save_nonce' ); ?>
    <?php if ( $editing ) : ?>
        <input type="hidden" name="tta_event_id" value="<?php echo esc_attr( $event['id'] ); ?>">
    <?php endif; ?>

    <!-- Always output waitlist_id for AJAX updates -->
    <input type="hidden" name="waitlist_id" id="waitlist_id"
           value="<?php echo esc_attr( $event['waitlist_id'] ?? 0 ); ?>">

    <table class="form-table">
        <tbody>
            <!-- Event Name -->
            <tr>
                <th>
                    <label for="name">Event Name</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Enter the title of the event as it will appear everywhere."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="text" name="name" id="name" class="regular-text"
                           value="<?php echo esc_attr( $event['name'] ?? '' ); ?>">
                </td>
            </tr>

            <!-- Date -->
            <tr>
                <th>
                    <label for="date">Date</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Choose the calendar date for this event."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="date" name="date" id="date"
                           value="<?php echo esc_attr( $event['date'] ?? '' ); ?>">
                </td>
            </tr>

            <!-- All-day Event? -->
            <tr>
                <th>
                    <label for="all_day_event">All-day Event?</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Check ‘Yes’ if the event spans the entire day."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <select name="all_day_event" id="all_day_event">
                        <option value="0" <?php selected( $event['all_day_event'] ?? '0', '0' ); ?>>No</option>
                        <option value="1" <?php selected( $event['all_day_event'] ?? '0', '1' ); ?>>Yes</option>
                    </select>
                </td>
            </tr>

            <!-- Start Time -->
            <tr>
                <th>
                    <label for="start_time">Start Time</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Use the time picker to select the event start time."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="time" name="start_time" id="start_time" class="regular-text"
                           value="<?php echo esc_attr( explode( '|', $event['time'] ?? '|' )[0] ?? '' ); ?>">
                </td>
            </tr>

            <!-- End Time -->
            <tr>
                <th>
                    <label for="end_time">End Time</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Use the time picker to select the event end time."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="time" name="end_time" id="end_time" class="regular-text"
                           value="<?php echo esc_attr( explode( '|', $event['time'] ?? '|' )[1] ?? '' ); ?>">
                </td>
            </tr>

            <!-- Virtual Event? -->
            <tr>
                <th>
                    <label for="virtual_event">Virtual Event?</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Check ‘Yes’ if this is an online-only event."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <select name="virtual_event" id="virtual_event">
                        <option value="0" <?php selected( $event['virtual_event'] ?? '0', '0' ); ?>>No</option>
                        <option value="1" <?php selected( $event['virtual_event'] ?? '0', '1' ); ?>>Yes</option>
                    </select>
                </td>
            </tr>

            <?php
            // Address split into pieces
            $parts = isset( $event['address'] ) ? explode( ' - ', $event['address'] ) : [];
            list( $street, $addr2, $city, $state, $zip ) = array_pad( $parts, 5, '' );
            ?>

            <!-- Street Address -->
            <tr>
                <th>
                    <label for="street_address">Street Address</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Enter the primary street address."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="text" name="street_address" id="street_address" class="regular-text"
                           value="<?php echo esc_attr( $street ); ?>">
                </td>
            </tr>

            <!-- Address 2 -->
            <tr>
                <th>
                    <label for="address_2">Address 2</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Apartment, suite, unit, etc."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="text" name="address_2" id="address_2" class="regular-text"
                           value="<?php echo esc_attr( $addr2 ); ?>">
                </td>
            </tr>

            <!-- City -->
            <tr>
                <th>
                    <label for="city">City</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="City name."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="text" name="city" id="city" class="regular-text"
                           value="<?php echo esc_attr( $city ); ?>">
                </td>
            </tr>

            <!-- State -->
            <tr>
                <th>
                    <label for="state">State</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Select the state."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <?php
                    $all_states = [
                        'Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware',
                        'Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky',
                        'Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi',
                        'Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico',
                        'New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania',
                        'Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont',
                        'Virginia','Washington','West Virginia','Wisconsin','Wyoming'
                    ];
                    $states = array_diff( $all_states, [ 'Virginia' ] );
                    sort( $states );
                    array_unshift( $states, 'Virginia' );
                    ?>
                    <select name="state" id="state">
                        <?php foreach ( $states as $st ) : ?>
                            <option value="<?php echo esc_attr( $st ); ?>"
                                <?php selected( $state, $st ); ?>>
                                <?php echo esc_html( $st ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>

            <!-- ZIP -->
            <tr>
                <th>
                    <label for="zip">ZIP</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Postal code."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="text" name="zip" id="zip" class="regular-text"
                           value="<?php echo esc_attr( $zip ); ?>">
                </td>
            </tr>

            <!-- Venue URL -->
            <tr>
                <th>
                    <label for="venueurl">Venue Link</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Link to the venue or event page."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="url" name="venueurl" id="venueurl" class="regular-text"
                           value="<?php echo esc_attr( $event['venueurl'] ?? '' ); ?>">
                </td>
            </tr>

            <!-- Event Type -->
            <tr>
                <th>
                    <label for="type">Event Type</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Select Free, Paid, or Member Only."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <select name="type" id="type">
                        <?php
                        $types = [ 'free'=>'Free', 'paid'=>'Paid', 'memberonly'=>'Member Only' ];
                        foreach ( $types as $val => $lbl ) {
                            printf(
                                '<option value="%1$s"%2$s>%3$s</option>',
                                esc_attr( $val ),
                                selected( $event['type'] ?? '', $val, false ),
                                esc_html( $lbl )
                            );
                        }
                        ?>
                    </select>
                </td>
            </tr>

            <!-- Base Cost -->
            <tr>
                <th>
                    <label for="baseeventcost">Base Cost</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Standard ticket price in USD."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="number" name="baseeventcost" id="baseeventcost" class="regular-text"
                           step="0.01" min="0"
                           value="<?php echo esc_attr( number_format_i18n( $event['baseeventcost'] ?? 0, 2 ) ); ?>">
                </td>
            </tr>

            <!-- Discounted Cost -->
            <tr>
                <th>
                    <label for="discountedmembercost">Discounted Cost</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Member discounted price in USD."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="number" name="discountedmembercost" id="discountedmembercost" class="regular-text"
                           step="0.01" min="0"
                           value="<?php echo esc_attr( number_format_i18n( $event['discountedmembercost'] ?? 0, 2 ) ); ?>">
                </td>
            </tr>

            <!-- Attendance Limit -->
            <tr>
                <th>
                    <label for="attendancelimit">Attendance Limit</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Set max attendees; 0 = unlimited."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="number" name="attendancelimit" id="attendancelimit" min="0" step="1"
                           value="<?php echo esc_attr( $event['attendancelimit'] ?? 0 ); ?>">
                </td>
            </tr>

            <!-- Waitlist Available? -->
            <tr>
                <th>
                    <label for="waitlistavailable">Waitlist Available?</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Allow joining waitlist when full."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <select name="waitlistavailable" id="waitlistavailable">
                        <option value="0"<?php selected( $event['waitlistavailable'] ?? 0, 0 ); ?>>No</option>
                        <option value="1"<?php selected( $event['waitlistavailable'] ?? 0, 1 ); ?>>Yes</option>
                    </select>
                </td>
            </tr>

            <!-- Refunds Available? -->
            <tr>
                <th>
                    <label for="refundsavailable">Refunds Available?</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Allow refund requests."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <select name="refundsavailable" id="refundsavailable">
                        <option value="0"<?php selected( $event['refundsavailable'] ?? 0, 0 ); ?>>No</option>
                        <option value="1"<?php selected( $event['refundsavailable'] ?? 0, 1 ); ?>>Yes</option>
                    </select>
                </td>
            </tr>

            <!-- Discount Code -->
            <tr>
                <th>
                    <label for="discountcode">Discount Code</label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Promo code & discount details."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="text" name="discountcode" id="discountcode" class="regular-text"
                           value="<?php echo esc_attr( $event['discountcode'] ?? '' ); ?>">
                </td>
            </tr>

            <!-- Extra Event Links -->
            <?php for ( $i = 2; $i <= 4; $i++ ) : ?>
            <tr>
                <th>
                    <label for="url<?php echo $i; ?>">Extra Event Link <?php echo $i - 1; ?></label>
                    <span class="tta-tooltip-icon"
                          data-tooltip="Additional resource link."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="url" name="url<?php echo $i; ?>" id="url<?php echo $i; ?>" class="regular-text"
                           value="<?php echo esc_attr( $event["url{$i}"] ?? '' ); ?>">
                </td>
            </tr>
            <?php endfor; ?>

        </tbody>
    </table>

    <h2>Event Images</h2>
    <table class="form-table">
        <tbody>
            <!-- Main Image -->
            <tr>
                <th>
                    Main Image
                    <span class="tta-tooltip-icon"
                          data-tooltip="Select a primary image."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="hidden" name="mainimageid" id="mainimageid"
                           value="<?php echo esc_attr( $event['mainimageid'] ?? '' ); ?>">
                    <button type="button" class="button tta-upload-single" data-target="#mainimageid">
                        Select Image
                    </button>
                    <div id="mainimage-preview" style="margin-top:10px;">
                        <?php if ( ! empty( $event['mainimageid'] ) ) {
                            echo wp_get_attachment_image( $event['mainimageid'], [150,150] );
                        } ?>
                    </div>
                </td>
            </tr>

            <!-- Gallery Images -->
            <tr>
                <th>
                    Gallery Images
                    <span class="tta-tooltip-icon"
                          data-tooltip="Choose multiple images."
                          style="margin-left:4px;">
                        <img src="<?php echo esc_url( TTA_PLUGIN_URL . 'assets/images/admin/question.svg' ); ?>"
                             alt="Help">
                    </span>
                </th>
                <td>
                    <input type="hidden" name="otherimageids" id="otherimageids"
                           value="<?php echo esc_attr( $event['otherimageids'] ?? '' ); ?>">
                    <button type="button" class="button tta-upload-multiple" data-target="#otherimageids">
                        Select Images
                    </button>
                    <div id="otherimage-preview" style="margin-top:10px;">
                        <?php
                        if ( ! empty( $event['otherimageids'] ) ) {
                            foreach ( explode( ',', $event['otherimageids'] ) as $aid ) {
                                echo wp_get_attachment_image(
                                    intval( $aid ),
                                    [100,100],
                                    false,
                                    [ 'style' => 'margin-right:5px;' ]
                                );
                            }
                        }
                        ?>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>

    <?php
    // Prepare waitlist display data
    $waitlist_id = intval( $event['waitlist_id'] ?? 0 );
    $wl_csv      = '';
    $userids     = [];
    if ( $waitlist_id ) {
        $wl_csv  = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT userids FROM {$wpdb->prefix}tta_waitlist WHERE id = %d",
                $waitlist_id
            )
        );
        $userids = $wl_csv ? explode( ',', $wl_csv ) : [];
    }
    // Show or hide based on dropdown
    $show_waitlist = ( $event['waitlistavailable'] ?? '0' ) === '1';
    ?>

    <div id="tta-waitlist-container" style="<?php echo $show_waitlist ? '' : 'display:none;'; ?>">
        <div class="tta-waitlist-holder-for-css">
            <h2>Current Waitlist</h2>
            <table class="form-table">
                <tbody>
                <?php if ( $userids ) : ?>
                    <?php foreach ( $userids as $pos => $uid ) :
                        $uid          = intval( $uid );
                        $user         = get_userdata( $uid );
                        $name         = $user ? $user->display_name : "User #{$uid}";
                        $profileimgid = $wpdb->get_var( $wpdb->prepare(
                            "SELECT profileimgid FROM {$wpdb->prefix}tta_members WHERE wpuserid = %d",
                            $uid
                        ) );
                        if ( $profileimgid ) {
                            $img = wp_get_attachment_image(
                                $profileimgid,
                                [32,32],
                                false,
                                [ 'alt' => esc_attr( $name ) ]
                            );
                        } else {
                            $placeholder = esc_url( TTA_PLUGIN_URL . 'assets/images/admin/placeholder-profile.svg' );
                            $img = '<img src="' . $placeholder . '" alt="Profile">';
                        }
                        $edit_link = admin_url( 'user-edit.php?user_id=' . $uid );
                    ?>
                    <tr class="tta-waitlist-entry" data-userid="<?php echo $uid; ?>">
                        <th>#<?php echo esc_html( $pos + 1 ); ?></th>
                        <td>
                            <?php echo $img; ?>
                            <a href="<?php echo esc_url( $edit_link ); ?>">
                                <?php echo esc_html( $name ); ?>
                            </a>
                            <button type="button"
                                    class="button-link tta-remove-waitlist">
                                Remove
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="2">No one is currently on the waitlist.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <p class="submit">
        <button type="submit" name="tta_event_save" class="button button-primary">
            <?php echo $editing ? 'Update Event' : 'Create Event'; ?>
        </button>
    </p>
</form>
