<?php
class TTA_Members_Admin {
    public static function get_instance() { static $inst; return $inst ?: $inst = new self(); }
    private function __construct() {
        add_action('admin_menu', array($this, 'register_menu'));
    }
    public function register_menu() {
        add_menu_page('Members', 'Members', 'manage_options', 'tta-members', array($this, 'render_list'), 'dashicons-groups', 6);
    }
    public function render_list() {
        // TODO: Implement WP_List_Table for Members
    }
}
?>