<?php
/**
 * Handles DB creation for the TTA plugin.
 */
class TTA_DB_Setup {
    public static function install() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $prefix = $wpdb->prefix . 'tta_';
        $tables = [];

        // Events table
        $tables[] = "CREATE TABLE {$prefix}events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ute_id VARCHAR(100) NOT NULL,
            name VARCHAR(255) NOT NULL,
            date DATE NOT NULL,
            baseeventcost DECIMAL(10,2) DEFAULT 0.00,
            discountedmembercost DECIMAL(10,2) DEFAULT 0.00,
            address VARCHAR(500) DEFAULT '',
            type VARCHAR(50) DEFAULT 'free',
            time VARCHAR(50) DEFAULT 'N/A',
            venueurl VARCHAR(255) DEFAULT '',
            url2 VARCHAR(255) DEFAULT '',
            url3 VARCHAR(255) DEFAULT '',
            url4 VARCHAR(255) DEFAULT '',
            mainimageid BIGINT UNSIGNED DEFAULT 0,
            otherimageids TEXT,
            attendancelimited TINYINT(1) DEFAULT 0,
            waitlistavailable TINYINT(1) DEFAULT 0,
            attendancelimit INT UNSIGNED DEFAULT 0,
            waitlist_id INT UNSIGNED DEFAULT 0,
            page_id INT UNSIGNED DEFAULT 0,
            ticket_id INT UNSIGNED DEFAULT 0,
            discountcode VARCHAR(255) DEFAULT '',
            all_day_event TINYINT(1) DEFAULT 0,
            virtual_event TINYINT(1) DEFAULT 0,
            refundsavailable TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY ute_id (ute_id)
        ) $charset_collate";

        // Members table
        $tables[] = "CREATE TABLE {$prefix}members (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            status VARCHAR(50) DEFAULT 'active',
            PRIMARY KEY (id),
            UNIQUE KEY email (email)
        ) $charset_collate";

        // Tickets table
        $tables[] = "CREATE TABLE {$prefix}tickets (
            id                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_ute_id           VARCHAR(100)     NOT NULL,
            event_name             VARCHAR(255)     NOT NULL,
            waitlist_id            INT UNSIGNED     NOT NULL,
            attendancelimit        INT UNSIGNED     NOT NULL,
            baseeventcost          DECIMAL(10,2)    NOT NULL,
            discountedmembercost   DECIMAL(10,2)    NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate";

        // Member history table
        $tables[] = "CREATE TABLE {$prefix}memberhistory (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            member_id BIGINT UNSIGNED NOT NULL,
            action_type VARCHAR(100) NOT NULL,
            action_data TEXT,
            action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY member_id (member_id)
        ) $charset_collate";

        // Waitlist table
        $tables[] = "CREATE TABLE {$prefix}waitlist (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_ute_id VARCHAR(100)     NOT NULL,
            ticket_id BIGINT UNSIGNED NOT NULL,
            event_name   VARCHAR(255)     NOT NULL,
            userids      TEXT             NOT NULL,
            added_at     DATETIME         DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $tables as $sql ) {
            dbDelta( $sql );
        }
    }

    public static function uninstall() {
        // No automatic drops by default
    }
}
