<?php
class TTA_Waitlist {
    public function add_to_waitlist($ute_id, $member_id) {
        // TODO: Add logic
    }
}
?>