<?php
class TTA_Events {
    // TODO: Events CRUD methods
}
?>