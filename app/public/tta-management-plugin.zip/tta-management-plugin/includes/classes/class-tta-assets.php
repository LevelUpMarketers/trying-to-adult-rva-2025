<?php
/**
 * Handles loading CSS & JS for admin and front-end.
 */
class TTA_Assets {

    /**
     * Hook into WP to enqueue assets.
     */
    public static function init() {
        add_action( 'admin_enqueue_scripts',   [ __CLASS__, 'enqueue_backend_assets' ] );
        add_action( 'wp_enqueue_scripts',      [ __CLASS__, 'enqueue_frontend_assets' ] );
    }

    /**
     * Enqueue admin-only CSS/JS.
     *
     * @param string $hook_suffix The current admin page.
     */
    public static function enqueue_backend_assets( $hook_suffix ) {
        // Load everywhere in WP-Admin so tooltips & media uploader are always available.

        // Enable media-library scripts for wp.media()
        wp_enqueue_media();

        // Admin CSS
        wp_enqueue_style(
            'tta-admin-css',
            TTA_PLUGIN_URL . 'assets/css/backend/admin.css',
            [],
            TTA_PLUGIN_VERSION
        );

        // Tooltip CSS (pure-CSS approach)
        wp_enqueue_style(
            'tta-tooltips-css',
            TTA_PLUGIN_URL . 'assets/css/backend/tooltips.css',
            [],
            TTA_PLUGIN_VERSION
        );

        // Media uploader JS
        wp_enqueue_script(
            'tta-admin-media',
            TTA_PLUGIN_URL . 'assets/js/backend/media-uploader.js',
            [ 'jquery' ],
            TTA_PLUGIN_VERSION,
            true
        );

        // **Make sure the WP editor API is available**
        wp_enqueue_editor();

        // Our AJAX form handler
        wp_enqueue_script(
            'tta-admin-js',
            TTA_PLUGIN_URL . 'assets/js/backend/admin.js',
            [ 'jquery' ],
            TTA_PLUGIN_VERSION,
            true
        );

        // Pass AJAX URL + nonces to our JS
        wp_localize_script(
            'tta-admin-js',
            'TTA_Ajax',
            [
                'ajax_url'         => admin_url( 'admin-ajax.php' ),
                'get_event_nonce'  => wp_create_nonce( 'tta_event_get_action' ),
                'save_event_nonce' => wp_create_nonce( 'tta_event_save_action' ),
            ]
        );
    }

    /**
     * Enqueue front-end CSS/JS.
     */
    public static function enqueue_frontend_assets() {
        wp_enqueue_style(
            'tta-frontend-css',
            TTA_PLUGIN_URL . 'assets/css/frontend/style.css',
            [],
            TTA_PLUGIN_VERSION
        );
    }
}

// Initialize the asset loader
TTA_Assets::init();
