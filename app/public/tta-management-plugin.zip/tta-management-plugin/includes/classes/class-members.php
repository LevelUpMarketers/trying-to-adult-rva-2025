<?php
class TTA_Members {
    // TODO: Members CRUD methods
}
?>