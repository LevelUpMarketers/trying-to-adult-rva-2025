<?php
class TTA_Tickets {
    // TODO: Tickets CRUD methods
}
?>