<?php
class TTA_AuthorizeNet_API {
    public function charge($amount, $card_details) {
        // TODO: Implement Authorize.Net API logic
    }
}
?>