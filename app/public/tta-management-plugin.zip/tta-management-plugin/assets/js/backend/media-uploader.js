jQuery(function($){

  // Single‐image uploader
  $('body').on('click', '.tta-upload-single', function(e){
    e.preventDefault();

    var $button  = $(this),
        $row     = $button.closest('tr'),
        $input   = $row.find('input[name="mainimageid"]'),
        $preview = $row.find('#mainimage-preview');

    // Create new media frame each time
    var frame = wp.media({
      title: 'Select or Upload an Image',
      button: { text: 'Use this image' },
      multiple: false
    });

    frame.on('select', function(){
      var attachment = frame.state().get('selection').first().toJSON();
      $input.val( attachment.id );

      // pick a thumbnail if available, fallback to full size
      var thumb = attachment.sizes && attachment.sizes.thumbnail
                  ? attachment.sizes.thumbnail.url
                  : attachment.url;

      $preview.html( '<img src="' + thumb + '" style="max-width:150px;"/>' );
    });

    frame.open();
  });


  // Multiple‐image uploader
  $('body').on('click', '.tta-upload-multiple', function(e){
    e.preventDefault();

    var $button  = $(this),
        $row     = $button.closest('tr'),
        $input   = $row.find('input[name="otherimageids"]'),
        $preview = $row.find('#otherimage-preview');

    var frame = wp.media({
      title: 'Select or Upload Images',
      button: { text: 'Use these images' },
      multiple: true
    });

    frame.on('select', function(){
      var selection = frame.state().get('selection'),
          ids       = [],
          html      = '';

      selection.each(function(attachment){
        attachment = attachment.toJSON();
        ids.push( attachment.id );

        var thumb = attachment.sizes && attachment.sizes.thumbnail
                    ? attachment.sizes.thumbnail.url
                    : attachment.url;

        html += '<img src="' + thumb + '" style="margin-right:5px;max-width:100px;"/>';
      });

      $input.val( ids.join(',') );
      $preview.html( html );
    });

    frame.open();
  });

});
