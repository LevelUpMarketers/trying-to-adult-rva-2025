jQuery(function($){

  //
  // Create New Event
  //
  var $createForm = $('#tta-event-form');
  if ( $createForm.length ) {
    $createForm.on('submit', function(e){
      e.preventDefault();
      var $btn = $createForm.find('.submit .button-primary').prop('disabled', true);
      var data = $createForm.serialize()
               + '&action=tta_save_event'
               + '&tta_event_save_nonce=' + TTA_Ajax.save_event_nonce;

      $.post(TTA_Ajax.ajax_url, data, function(res){
        $('#tta-event-notice').remove();
        var cls = res.success ? 'updated' : 'error';
        var msg = res.data.message || 'Unknown error';
        $('<div id="tta-event-notice" class="' + cls + ' notice"><p>' + msg + '</p></div>')
          .insertBefore( $createForm );
        if ( res.success && res.data.id && !$createForm.find('input[name="tta_event_id"]').length ) {
          $createForm.prepend('<input type="hidden" name="tta_event_id" value="' + res.data.id + '">');
        }
      }, 'json')
      .always(function(){
        $btn.prop('disabled', false);
      });
    });
  }

  //
  // Inline Edit: fetch & inject an edit form when clicking a row
  //
  $(document).on('click', '.widefat tbody tr[data-event-id]', function(e){
    // Don’t trigger if clicking inside controls
    if ($(e.target).is('a, button, input, textarea, select')) {
      return;
    }

    var $row     = $(this);
    var eventId  = $row.data('event-id');
    var colspan  = $row.find('td').length;
    var $arrow   = $row.find('.tta-toggle-arrow');
    var $existing= $row.next('.tta-inline-row');

    // If already open, close it
    if ( $existing.length ) {
      $arrow.removeClass('open');
      $existing.find('.tta-inline-container').fadeOut(200, function(){
        $existing.remove();
      });
      return;
    }

    // Close any other open
    $('.tta-inline-row').each(function(){
      var $otherRow = $(this).prev('tr');
      $otherRow.find('.tta-toggle-arrow').removeClass('open');
      $(this).find('.tta-inline-container').fadeOut(200, function(){
        $(this).closest('.tta-inline-row').remove();
      });
    });

    // Start arrow animation immediately
    $arrow.addClass('open');

    // Fetch the pre-populated edit form HTML
    $.post(TTA_Ajax.ajax_url, {
      action:            'tta_get_event_form',
      event_id:          eventId,
      get_event_nonce:   TTA_Ajax.get_event_nonce
    }, function(res){
      if ( ! res.success ) {
        console.error('Error fetching form:', res.data && res.data.message);
        return;
      }
      var html = res.data.html;

      // Inject inline row with hidden container and fade it in
      var $newRow = $(
        '<tr class="tta-inline-row">' +
          '<td colspan="' + colspan + '">' +
            '<div class="tta-inline-container" style="display:none;"></div>' +
          '</td>' +
        '</tr>'
      );
      $row.after($newRow);

      var $container = $newRow.find('.tta-inline-container');
      $container.html(html).fadeIn(200, function(){
        // After fadeIn completes, scroll viewport so this row is in view,
        // leaving 120px above it so the trigger row stays visible.
        var offset = $newRow.offset().top;
        $('html, body').animate({ scrollTop: offset - 120 }, 300);
      });
    }, 'json');
  });

  //
  // Also open inline edit when clicking the Edit link
  //
  $(document).on('click', '.tta-edit-link', function(e){
    e.preventDefault();
    $(this).closest('tr').trigger('click');
  });

  //
  // Update Existing Event (delegate to injected form)
  //
  $(document).on('submit', '#tta-event-edit-form', function(e){
    e.preventDefault();
    var $form = $(this);
    var $btn  = $form.find('.submit .button-primary').prop('disabled', true);

    // Rebuild userids before serializing
    rebuildUserids();

    var data = $form.serialize()
             + '&action=tta_update_event'
             + '&tta_event_save_nonce=' + TTA_Ajax.save_event_nonce;

    $.post(TTA_Ajax.ajax_url, data, function(res){
      $('#tta-event-notice').remove();
      var cls = res.success ? 'updated' : 'error';
      var msg = res.data.message || 'Unknown error';
      $('<div id="tta-event-notice" class="' + cls + ' notice"><p>' + msg + '</p></div>')
        .insertBefore( $form );
    }, 'json')
    .always(function(){
      $btn.prop('disabled', false);
    });
  });

  //
  // Remove a waitlist entry
  //
  $(document).on('click', '.tta-remove-waitlist', function(e){
    e.preventDefault();
    $(this).closest('.tta-waitlist-entry').remove();
    rebuildUserids();
  });

  //
  // Show/hide waitlist section when dropdown changes
  //
  $(document).on('change', '#waitlistavailable', function(){
    if ( $(this).val() === '1' ) {
      $('#tta-waitlist-container').slideDown(200);
    } else {
      $('#tta-waitlist-container').slideUp(200);
    }
  });

  //
  // Rebuild the CSV of user IDs and store in a hidden input
  //
  function rebuildUserids(){
    var uids = [];
    $('#tta-waitlist-container .tta-waitlist-entry').each(function(){
      uids.push( $(this).data('userid') );
    });
    var csv = uids.join(',');
    var $form = $('#tta-event-edit-form');
    var $input = $form.find('input[name="userids"]');
    if ( ! $input.length ) {
      $input = $('<input>')
        .attr({ type: 'hidden', name: 'userids' })
        .appendTo( $form );
    }
    $input.val(csv);
  }

});
